# PWA-Dicoding
Progressive Web Apps adalah aplikasi web yang memanfaatkan beragam fitur web modern sehingga dapat menyajikan pengalaman pengguna seperti aplikasi native. PWA mengubah sajian tampilan yang umumnya dibuka melalui halaman browser menjadi jendela aplikasi tersendiri. Selain itu PWA juga memungkinkan konten halaman diakses dalam mode offline, menampilkan pesan pemberitahuan, hingga akses ke hardware dari perangkat seperti halnya native app.

Progressive Web App dapat menyajikan aplikasi web yang dapat diandalkan, cepat dan menjaga ikatan dengan pengguna.

Kelas Membangun Progressive Web Apps dikembangkan oleh Codepolitan dengan kerja sama dengan Dicoding.
https://www.dicoding.com/academies/74
