## dicoding-pwa

Submissions for Dicoding's Course "Membangun Progressive Web Apps"

Link to this app (Submission 3) -> https://pwa-bundesliga.web.app/
