var webPush = require('web-push');

const vapidKeys = {
    "publicKey": "BJA0e92zF8MWdZgJvPtFLqVQT-00Jc1fhGPjRRI72-RupcdAPaHSSISFEmJaEJ3nw_vhmcb_csSzTqytkYKn_Sw",
    "privateKey": "v6wHfhxPL3v_aQgTTp-cmveeDlEghkt9H9vjJnEsVUY"
};

webPush.setVapidDetails(
    'mailto:example@yourdomain.org',
    vapidKeys.publicKey,
    vapidKeys.privateKey
)
var pushSubscription = {
    "endpoint": "https://fcm.googleapis.com/fcm/send/csGlBntWjYk:APA91bHQVdU_hu2E8-cj2XbTq4TSh7ngtj50PcQYXqap3zSqt8rAMys8bvNWGsbUYHcabHSYIgH0MAZP-VCxOyLC63OFB0NgxdnM473GHBW-fdOS0l9OwkhwjlkdAnGdyLS0Ps8ijhnu",
    "keys": {
        "p256dh": "BMt373cEBZFYVL5EG00qyQ9WE5MhQao4UzFeS0ADT7Zq29vfgeMVRWuKOBFFinkNgOgE8mThZAY86PQN1vIryD0=",
        "auth": "AwpJVPb8Xk8HANAlZt0gHA=="
    }
};
var payload = 'Selamat Datang Di PWA Football';

var options = {
    gcmAPIKey: '733217470388',
    TTL: 60
};

webPush.sendNotification(
    pushSubscription,
    payload,
    options
);