importScripts('https://storage.googleapis.com/workbox-cdn/releases/3.6.3/workbox-sw.js');

// Cek workbox
if (workbox)
    console.log(`Workbox berhasil dimuat`);
else
    console.log(`Workbox gagal dimuat`);

// Mendaftarkan file
workbox.precaching.precacheAndRoute([
    { url: '/index.html', revision: '1' },
    { url: '/nav.html', revision: '1' },
    { url: '/favicon.ico', revision: '1' },
    { url: '/push.js', revision: '1' },
    { url: '/package-lock.json', revision: '1' },
    { url: '/package.json', revision: '1' },
    { url: '/detail_match.html', revision: '1' },
    { url: '/detail_player.html', revision: '1' },
    { url: '/detail_team.html', revision: '1' },
    { url: '/manifest.json', revision: '1' },
    { url: '/images/icon-72x72.png', revision: '1' },
    { url: '/images/icon-128x128.png', revision: '1' },
    { url: '/images/icon-144x144.png', revision: '1' },
    { url: '/images/icon-152x152.png', revision: '1' },
    { url: '/images/icon-192x192.png', revision: '1' },
    { url: '/images/icon-384x384.png', revision: '1' },
    { url: '/images/icon-512x512.png', revision: '1' },
    { url: '/images/stadion.jpg', revision: '1' },
    { url: '/images/icon.png', revision: '1' },
    { url: '/css/main.css', revision: '1' },
    { url: '/css/materialize.min.css', revision: '1' },
    { url: '/css/materialize.css', revision: '1' },
    { url: '/css/fontawesome/fontawesome.min.css', revision: '1' },
    { url: '/css/fontawesome/all.min.css', revision: '1' },
    { url: '/css/webfonts/fa-solid-900.eot', revision: '1' },
    { url: '/css/webfonts/fa-solid-900.svg', revision: '1' },
    { url: '/css/webfonts/fa-solid-900.ttf', revision: '1' },
    { url: '/css/webfonts/fa-solid-900.woff', revision: '1' },
    { url: '/css/webfonts/fa-solid-900.woff2', revision: '1' },
    { url: '/css/webfonts/fa-brands-400.eot', revision: '1' },
    { url: '/css/webfonts/fa-brands-400.svg', revision: '1' },
    { url: '/css/webfonts/fa-brands-400.ttf', revision: '1' },
    { url: '/css/webfonts/fa-brands-400.woff', revision: '1' },
    { url: '/css/webfonts/fa-brands-400.woff2', revision: '1' },
    { url: '/css/webfonts/fa-regular-400.eot', revision: '1' },
    { url: '/css/webfonts/fa-regular-400.svg', revision: '1' },
    { url: '/css/webfonts/fa-regular-400.ttf', revision: '1' },
    { url: '/css/webfonts/fa-regular-400.woff', revision: '1' },
    { url: '/css/webfonts/fa-regular-400.woff2', revision: '1' },
    { url: '/js/api.js', revision: '1' },
    { url: '/js/materialize.js', revision: '1' },
    { url: '/js/jquery.min.js', revision: '1' },
    { url: '/js/nav.js', revision: '1' },
    { url: '/js/klasemen.js', revision: '1' },
    { url: '/js/latestmatch.js', revision: '1' },
    { url: '/js/upcoming.js', revision: '1' },
    { url: '/js/matchleague.js', revision: '1' },
    { url: '/js/detail_team.js', revision: '1' },
    { url: '/js/detail_match.js', revision: '1' },
    { url: '/js/idb.js', revision: '1' },
    { url: '/js/dbfootball.js', revision: '1' },
    { url: '/js/dbfunction.js', revision: '1' },
    { url: '/js/materialize.min.js', revision: '1' },
    { url: '/js/main.js', revision: '1' },
]);

workbox.routing.registerRoute(
    new RegExp('/pages/'),
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'pages'
    })
);

workbox.routing.registerRoute(
    /^https:\/\/api\.football-data\.org\/v2/,
    workbox.strategies.staleWhileRevalidate({
        cacheName: 'base_url',
    })
);

self.addEventListener('push', function(event) {
    var body;
    if (event.data) {
        body = event.data.text();
    } else {
        body = 'Push message no payload';
    }
    var options = {
        body: body,
        icon: 'img/notification.png',
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        }
    };
    event.waitUntil(
        self.registration.showNotification('Push Notification', options)
    );
});