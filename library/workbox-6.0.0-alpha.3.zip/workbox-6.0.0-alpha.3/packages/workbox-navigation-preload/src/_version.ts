// @ts-ignore
try{self['workbox:navigation-preload:6.0.0-alpha.2']&&_()}catch(e){}