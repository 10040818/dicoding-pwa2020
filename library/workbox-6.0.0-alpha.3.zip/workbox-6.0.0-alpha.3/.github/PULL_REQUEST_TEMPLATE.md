**Prior to filing a PR, please:**
- [open an issue](https://github.com/GoogleChrome/workbox/issues/new) to discuss your proposed change.
- ensure that `gulp build && gulp lint test` passes locally.

R: @jeffposnick @philipwalton

Fixes #*issue number*

*Description of what's changed/fixed.*
