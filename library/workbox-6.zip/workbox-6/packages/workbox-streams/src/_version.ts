// @ts-ignore
try{self['workbox:streams:6.0.0-alpha.3']&&_()}catch(e){}