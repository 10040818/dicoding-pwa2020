// @ts-ignore
try{self['workbox:window:6.0.0-alpha.3']&&_()}catch(e){}