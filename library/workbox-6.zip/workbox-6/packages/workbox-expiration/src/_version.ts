// @ts-ignore
try{self['workbox:expiration:6.0.0-alpha.3']&&_()}catch(e){}