// @ts-ignore
try{self['workbox:precaching:6.0.0-alpha.3']&&_()}catch(e){}